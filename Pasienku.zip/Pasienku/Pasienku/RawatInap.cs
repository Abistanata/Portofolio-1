﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data;
using System.Data.SqlClient;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Pasienku
{
    public partial class RawatInap : Form
    {
        SqlConnection connect = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\THINKPAD\Documents\MainApl.mdf;Integrated Security=True;Connect Timeout=30;Encrypt=False");
        public RawatInap()
        {
            InitializeComponent();
        }

        private void lblDataPasien_Click(object sender, EventArgs e)
        {
            MainForm pForm = new MainForm();
            pForm.Show();
            this.Hide();
        }

        private void RawatInap_Load(object sender, EventArgs e)
        {
            TampilkanDataRawatInap();
        }
        private void ExecuteQuery(string query)
        {
            try
            {
                connect.Open();
                SqlCommand cmd = new SqlCommand(query, connect);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Operasi berhasil!");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}");
            }
            finally
            {
                connect.Close();
            }
        }

        private void TampilkanDataRawatInap()
        {
            try
            {
                connect.Open();
                SqlDataAdapter da = new SqlDataAdapter("SELECT * FROM rawat_inap", connect);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dataGridView1.DataSource = dt;

                // Pastikan kolom id_ruangan terlihat
                dataGridView1.Columns["id_ruangan"].Visible = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}");
            }
            finally
            {
                connect.Close();
            }
        }

        private void btnTambah_Click(object sender, EventArgs e)
        {
            string query = $"INSERT INTO rawat_inap (nama_kamar, id_pasien, tanggal_masuk, tanggal_keluar) " +
            $"VALUES ('{txtNamaKamar.Text}', '{txtIDPasien.Text}', '{dtpTanggalMasuk.Value.ToString("yyyy-MM-dd")}', " +
            $"'{(dtpTanggalKeluar.Checked ? dtpTanggalKeluar.Value.ToString("yyyy-MM-dd") : "NULL")}')";

            ExecuteQuery(query);
            TampilkanDataRawatInap();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            string query = $"UPDATE rawat_inap SET " +
            $"nama_kamar = '{txtNamaKamar.Text}', " +
            $"tanggal_masuk = '{dtpTanggalMasuk.Value.ToString("yyyy-MM-dd")}', " +
            $"tanggal_keluar = '{dtpTanggalKeluar.Value.ToString("yyyy-MM-dd")}' " +
            $"WHERE id_pasien = '{txtIDPasien.Text}'"; // Gunakan id_pasien sebagai kriteria
            ExecuteQuery(query);
            TampilkanDataRawatInap();
        }

        private void btnHapus_Click(object sender, EventArgs e)
        {
            string query = $"DELETE FROM rawat_inap WHERE id_pasien = {txtIDPasien.Text}";
            ExecuteQuery(query);
            TampilkanDataRawatInap();
        }

        private void Main_close_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            try
            {
                connect.Open();

                // Gunakan parameter untuk mencegah SQL Injection
                string query = "SELECT * FROM rawat_inap WHERE id_ruangan = @id";
                SqlCommand cmd = new SqlCommand(query, connect);
                cmd.Parameters.AddWithValue("@id", txtSearchID.Text); // Ambil input dari txtSearchID

                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);

                if (dt.Rows.Count > 0)
                {
                    // Tampilkan hasil pencarian di DataGridView
                    dataGridView2.DataSource = dt; // Gunakan DataGridView khusus untuk hasil pencarian
                }
                else
                {
                    MessageBox.Show("Data tidak ditemukan.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}");
            }
            finally
            {
                connect.Close();
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
