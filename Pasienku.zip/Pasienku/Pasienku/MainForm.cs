﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data;
using System.Data.SqlClient;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Pasienku
{
    public partial class MainForm : Form
    {
        SqlConnection connect = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\THINKPAD\Documents\MainApl.mdf;Integrated Security=True;Connect Timeout=30;Encrypt=False");
        public MainForm()
        {
            InitializeComponent();
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            TampilkanData();
            // Tambahkan opsi ke ComboBox
            cmbJenisKelamin.Items.Add("Laki-Laki");
            cmbJenisKelamin.Items.Add("Perempuan");

        }
        private void ExecuteQuery(string query)
        {
            try
            {
                connect.Open();
                SqlCommand cmd = new SqlCommand(query, connect);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Operasi berhasil!");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}");
            }
            finally
            {
                connect.Close();
            }
        }
        private void TampilkanData()
        {
            try
            {
                connect.Open();
                SqlDataAdapter da = new SqlDataAdapter("SELECT * FROM pasien", connect);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dataGridView1.DataSource = dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}");
            }
            finally
            {
                connect.Close();
            }

            try
            {
                connect.Open();
                SqlDataAdapter da = new SqlDataAdapter("SELECT * FROM pasien", connect);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dataGridView1.DataSource = dt;

                // Pastikan kolom ID pasien terlihat
                dataGridView1.Columns["id_pasien"].Visible = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}");
            }
            finally
            {
                connect.Close();
            }
        }

        private void btnTambah_Click(object sender, EventArgs e)
        {
            string query = $"INSERT INTO pasien (nama, alamat, no_hp, jenis_kelamin, tanggal_lahir) " +
                               $"VALUES ('{txtNama.Text}', '{txtAlamat.Text}', '{txtNoHp.Text}', '{cmbJenisKelamin.Text}', '{dtpTanggalLahir.Value.ToString("yyyy-MM-dd")}')";
            ExecuteQuery(query);
            TampilkanData();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            string query = $"UPDATE pasien SET nama = '{txtNama.Text}', alamat = '{txtAlamat.Text}', " +
        $"jenis_kelamin = '{cmbJenisKelamin.Text}', tanggal_lahir = '{dtpTanggalLahir.Value.ToString("yyyy-MM-dd")}' " +
        $"WHERE no_hp = '{txtNoHp.Text}'"; // Gunakan kolom no_hp sebagai pengganti id
            ExecuteQuery(query);
            TampilkanData();
        }

        private void btnHapus_Click(object sender, EventArgs e)
        {
            string query = $"DELETE FROM pasien WHERE nama = '{txtNama.Text}'"; // Gunakan no_hp untuk identifikasi
            ExecuteQuery(query);
            TampilkanData();
        }

        private void Main_close_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

            if (e.RowIndex >= 0) // Pastikan baris valid
            {
                DataGridViewRow row = dataGridView1.Rows[e.RowIndex];

                // Mengisi data dari DataGridView ke TextBox dan ComboBox di form
                txtNama.Text = row.Cells["nama"].Value.ToString();
                txtAlamat.Text = row.Cells["alamat"].Value.ToString();
                txtNoHp.Text = row.Cells["no_hp"].Value.ToString();
                cmbJenisKelamin.Text = row.Cells["jenis_kelamin"].Value.ToString();
                dtpTanggalLahir.Value = Convert.ToDateTime(row.Cells["tanggal_lahir"].Value);

                // Tidak perlu mengisi ID ke TextBox
            }
        }

        private void cmbJenisKelamin_SelectedIndexChanged(object sender, EventArgs e)
        {
            int pilih;

            pilih = cmbJenisKelamin.SelectedIndex;
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            try
            {
                connect.Open();
                // Gunakan parameter untuk mencegah SQL Injection
                string query = "SELECT * FROM pasien WHERE id_pasien = @id";
                SqlCommand cmd = new SqlCommand(query, connect);
                cmd.Parameters.AddWithValue("@id", txtSearchID.Text); // Ambil input dari txtSearchID

                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);

                if (dt.Rows.Count > 0)
                {
                    // Tampilkan hasil pencarian di DataGridView
                    dataGridView2.DataSource = dt; // Gunakan DataGridView khusus untuk hasil pencarian
                }
                else
                {
                    MessageBox.Show("Data tidak ditemukan.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}");
            }
            finally
            {
                connect.Close();
            }
        }

        private void lblRawatInap_Click(object sender, EventArgs e)
        {
            RawatInap rForm = new RawatInap();
            rForm.Show();
            this.Hide();
        }
    }
}
